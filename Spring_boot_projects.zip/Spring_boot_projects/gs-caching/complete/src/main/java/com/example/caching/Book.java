package com.example.caching;

// Classe Book per rappresentare un libro con ISBN e titolo.
public class Book {

	// Variabile di istanza privata per l'ISBN del libro.
	private String isbn;

	// Variabile di istanza privata per il titolo del libro.
	private String title;

	// Costruttore della classe Book che inizializza isbn e titolo.
	public Book(String isbn, String title) {
		this.isbn = isbn; // Imposta l'ISBN del libro.
		this.title = title; // Imposta il titolo del libro.
	}

	// Metodo getter per ottenere l'ISBN del libro.
	public String getIsbn() {
		return isbn;
	}

	// Metodo setter per impostare un nuovo ISBN al libro.
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	// Metodo getter per ottenere il titolo del libro.
	public String getTitle() {
		return title;
	}

	// Metodo setter per impostare un nuovo titolo al libro.
	public void setTitle(String title) {
		this.title = title;
	}

	// Metodo toString sovrascritto per fornire una rappresentazione stringa del libro.
	// Utile per la stampa delle informazioni del libro nei log o in console.
	@Override
	public String toString() {
		return "Book{" + "isbn='" + isbn + '\'' + ", title='" + title + '\'' + '}';
	}

}
