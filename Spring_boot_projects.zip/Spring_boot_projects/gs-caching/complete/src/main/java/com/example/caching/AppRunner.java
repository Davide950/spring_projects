package com.example.caching;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

// Componente che implementa CommandLineRunner per eseguire codice all'avvio dell'applicazione.
@Component
public class AppRunner implements CommandLineRunner {

	// Logger per registrare messaggi di log (debugging, info, errori, ecc.).
	private static final Logger logger = LoggerFactory.getLogger(AppRunner.class);

	// Dipendenza su un repository di libri, utilizzato per recuperare dati dei libri.
	private final BookRepository bookRepository;

	// Costruttore per l'iniezione di dipendenza del BookRepository.
	public AppRunner(BookRepository bookRepository) {
		this.bookRepository = bookRepository;
	}

	// Metodo che verrà eseguito automaticamente all'avvio dell'applicazione.
	@Override
	public void run(String... args) throws Exception {
		// Registra un messaggio di informazione indicando l'inizio del recupero dei libri.
		logger.info(".... Fetching books");

		// Esegue il metodo getByIsbn del repository per il libro con ISBN "isbn-1234" e logga il risultato.
		logger.info("isbn-1234 -->" + bookRepository.getByIsbn("isbn-1234"));

		// Recupera e logga il libro con ISBN "isbn-4567".
		logger.info("isbn-4567 -->" + bookRepository.getByIsbn("isbn-4567"));

		// Ripete il recupero e logging di più libri per dimostrare il caching o la ripetizione di query.
		logger.info("isbn-1234 -->" + bookRepository.getByIsbn("isbn-1234"));
		logger.info("isbn-4567 -->" + bookRepository.getByIsbn("isbn-4567"));
		logger.info("isbn-1234 -->" + bookRepository.getByIsbn("isbn-1234"));
		logger.info("isbn-1234 -->" + bookRepository.getByIsbn("isbn-1234"));
	}

}
