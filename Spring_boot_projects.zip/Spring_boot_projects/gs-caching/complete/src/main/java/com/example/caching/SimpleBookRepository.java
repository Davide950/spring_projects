package com.example.caching;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

// Componente Spring che implementa l'interfaccia BookRepository.
@Component
public class SimpleBookRepository implements BookRepository {

	// Metodo annotato con @Cacheable che indica che il risultato del metodo deve essere memorizzato nella cache.
	// "books" è il nome della cache dove i risultati saranno memorizzati.
	@Override
	@Cacheable("books")
	public Book getByIsbn(String isbn) {
		simulateSlowService(); // Simula un servizio lento per dimostrare l'efficacia della cache.
		return new Book(isbn, "Some book"); // Restituisce un nuovo libro con un titolo generico.
	}

	// Metodo privato per simulare una risposta lenta di un servizio.

	private void simulateSlowService() {
		try {
			long time = 3000L; // Ritardo di 3000 millisecondi (3 secondi).
			Thread.sleep(time); // Mette il thread corrente in pausa per il tempo specificato.
		} catch (InterruptedException e) {
			throw new IllegalStateException(e); // Gestisce l'interruzione del thread lanciando un'eccezione.
		}
	}

}

