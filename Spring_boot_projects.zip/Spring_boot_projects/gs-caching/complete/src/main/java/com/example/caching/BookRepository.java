package com.example.caching;

// Interfaccia BookRepository per definire le operazioni sui libri.
public interface BookRepository {

	// Metodo per ottenere un libro in base al suo ISBN.
	// Questo metodo deve essere implementato dalle classi che aderiscono a questa interfaccia.
	Book getByIsbn(String isbn);

}

