package com.example.securingweb;

// Importazione delle classi necessarie per la configurazione MVC e Spring
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

// Annotazione per dichiarare questa classe come una classe di configurazione che contribuisce al contesto di Spring.
@Configuration
public class MvcConfig implements WebMvcConfigurer {

	// Sovrascrittura del metodo dall'interfaccia WebMvcConfigurer per configurare i controller di vista
	@Override
	public void addViewControllers(ViewControllerRegistry registry) {
		// Mappatura dell'URL "/home" alla vista "home" (home.html o home.jsp a seconda della configurazione)
		registry.addViewController("/home").setViewName("home");

		// Mappatura dell'URL radice "/" per puntare anche alla vista "home"
		registry.addViewController("/").setViewName("home");

		// Mappatura dell'URL "/hello" alla vista "hello" (hello.html)
		registry.addViewController("/hello").setViewName("hello");

		// Mappatura dell'URL "/login" alla vista "login" (login.html)
		registry.addViewController("/login").setViewName("login");
	}

}

