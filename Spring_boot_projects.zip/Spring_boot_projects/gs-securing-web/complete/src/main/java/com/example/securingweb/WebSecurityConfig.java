package com.example.securingweb;

// Importazione delle classi necessarie per la configurazione di Spring Security
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

// Classe di configurazione per abilitare la sicurezza web
@Configuration
@EnableWebSecurity
public class WebSecurityConfig {

	// Definizione del bean per la catena di filtri di sicurezza
	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
		http
				// Configurazione delle regole di autorizzazione per le richieste HTTP
				.authorizeHttpRequests((requests) -> requests
						// Permette l'accesso senza autenticazione alle pagine "/" e "/home"
						.requestMatchers("/", "/home").permitAll()
						// Richiede l'autenticazione per tutte le altre richieste
						.anyRequest().authenticated()
				)
				// Configurazione della pagina e del processo di login
				.formLogin((form) -> form
						.loginPage("/login")  // Imposta la pagina di login personalizzata
						.permitAll()          // Permette l'accesso alla pagina di login a tutti
				)
				// Configurazione del processo di logout
				.logout((logout) -> logout.permitAll()); // Permette il logout a tutti

		// Costruisce e ritorna l'oggetto HttpSecurity configurato
		return http.build();
	}

	// Definizione del bean per il servizio di gestione degli utenti
	@Bean
	public UserDetailsService userDetailsService() {
		// Creazione di un utente con username "user" e password "password"
		UserDetails user =
				User.withDefaultPasswordEncoder()  // Utilizza un encoder di password predefinito
						.username("user")
						.password("password")
						.roles("USER") // Assegna il ruolo 'USER' all'utente
						.build();

		// Memorizza le credenziali dell'utente in memoria
		return new InMemoryUserDetailsManager(user);
	}
}

