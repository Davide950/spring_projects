package com.example.restservicecors;

import org.junit.jupiter.api.Test;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class RestServiceCorsApplicationTests {

	@Test
	public void contextLoads() {
	}

}
