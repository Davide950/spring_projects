package com.example.restservicecors;

import java.util.concurrent.atomic.AtomicLong;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

// Annotazione RestController indica che questa classe è un controller dove
// ogni metodo restituisce un dominio dell'oggetto invece di una vista.
@RestController
public class GreetingController {

	// Template di stringa per il formato del saluto.
	private static final String template = "Hello, %s!";

	// Contatore atomico per garantire un incremento sicuro e unico tra diversi thread.
	private final AtomicLong counter = new AtomicLong();

	// Annotazione CrossOrigin permette le richieste CORS da origini specifiche.
	@CrossOrigin(origins = "http://localhost:9000")
	@GetMapping("/greeting")  // Mappa richieste GET all'URL /greeting al metodo sottostante.
	public Greeting greeting(@RequestParam(required = false, defaultValue = "World") String name) {
		// Stampa di controllo nel server log per tracciare l'accesso a questo metodo.
		System.out.println("==== get greeting ====");
		// Crea e restituisce un nuovo oggetto Greeting con ID incrementato e contenuto personalizzato.
		return new Greeting(counter.incrementAndGet(), String.format(template, name));
	}

	@GetMapping("/greeting-javaconfig")  // Secondo endpoint per un esempio senza annotazione CrossOrigin.
	public Greeting greetingWithJavaconfig(@RequestParam(required = false, defaultValue = "World") String name) {
		// Stampa di controllo simile al metodo precedente.
		System.out.println("==== in greeting ====");
		// Comportamento identico al metodo greeting, restituisce un nuovo Greeting.
		return new Greeting(counter.incrementAndGet(), String.format(template, name));
	}

}

