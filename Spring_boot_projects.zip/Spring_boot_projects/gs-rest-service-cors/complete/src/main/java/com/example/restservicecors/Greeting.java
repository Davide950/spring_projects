package com.example.restservicecors;

// Classe Greeting per rappresentare un saluto con un ID e un contenuto testuale.
public class Greeting {

	// Campo privato per l'ID del saluto, non modificabile una volta impostato.
	private final long id;

	// Campo privato per il contenuto del saluto, non modificabile una volta impostato.
	private final String content;

	// Costruttore senza parametri che inizializza un oggetto Greeting con valori di default.
	public Greeting() {
		this.id = -1;  // Imposta l'ID di default a -1, indicando un oggetto non inizializzato o nullo.
		this.content = "";  // Imposta il contenuto di default a una stringa vuota.
	}

	// Costruttore che accetta un ID e una stringa di contenuto.
	// Questo consente di creare un oggetto Greeting con valori specifici.
	public Greeting(long id, String content) {
		this.id = id;  // Imposta l'ID del saluto con il valore fornito.
		this.content = content;  // Imposta il contenuto del saluto con la stringa fornita.
	}

	// Metodo pubblico per ottenere l'ID del saluto.
	public long getId() {
		return id;  // Ritorna l'ID del saluto.
	}

	// Metodo pubblico per ottenere il contenuto del saluto.
	public String getContent() {
		return content;  // Ritorna il contenuto del saluto.
	}
}

